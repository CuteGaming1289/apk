pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "aura-ai"

// Modules are added as they are implemented. `agent` is pure Kotlin/JVM so it can
// be unit-tested without the Android SDK.
include(":app")
include(":agent")
