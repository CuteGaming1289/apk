# AURA AI

## Status (honest)
- `backend/`: built and tested here. `cd backend && npm test` -> 11/11 pass.
- Android app (`app/`, `agent/`): source is complete for the pipeline below, but it was
  **never compiled or run** (the authoring sandbox had no Android SDK and no network).
  Expect to fix a few compile errors on first build. Send them back and they get fixed.
  One thing to watch: `fun interface ConfirmationManager` has a `suspend` method; if your
  Kotlin version rejects SAM lambdas for it, turn it into a normal interface.

## What the app is meant to do
Voice or text -> backend -> Claude picks allowlisted tools -> app executes natively ->
Claude reports the real outcome in the user's language -> spoken reply.

| Command | Behaviour |
|---|---|
| call X | finds contact, asks if several match, confirms, opens dialer (user presses call) |
| message X ... | drafts SMS, confirms, opens composer (user presses send) |
| open app | launcher apps only; asks if ambiguous |
| find videos/photos | MediaStore search with thumbnails; date and name filters |
| delete file | only items from the latest search; confirm dialog + system consent; success only if file is gone |
| web search | real results via backend (Brave); tools are locked afterwards so web text cannot trigger actions |
| reminders/alarms | AlarmManager.setAlarmClock + notification; alarms via Clock app; reboot rescheduling |
| several steps | sequential TaskExecutor; stops on failure/denial; cancel button |

## Known gaps and limits
- Wake word: uses the ON-DEVICE speech recognizer (Android 13+ with offline pack), not Porcupine.
  Less accurate and heavier on battery than a real wake-word engine. Needs testing on hardware.
- From the background, Android may block opening other apps/dialer. Works reliably with AURA open.
  Spoken yes/no confirmation is used when the UI is not visible. Deletion needs AURA open.
- Not implemented: video upload (needs a destination), Room database, DataStore (SharedPreferences
  used instead), persistent conversation history, TTS voice picker, per-language availability badges.
- Contact matching is plain text matching: a Hindi-script name will not match a Latin-script contact.
- Language support depends on the phone's installed speech and TTS packs.
- Manufacturer battery managers (Xiaomi, Oppo, Vivo, Samsung) may kill the listening service.
- Unit tests exist only for `TaskExecutor` (7) and the backend (11).

## Run the backend
```
export AURA_SERVER_SECRET="$(openssl rand -hex 32)"
export ANTHROPIC_API_KEY=...          # never put this in the APK
export BRAVE_SEARCH_API_KEY=...       # for web search
cd backend && npm start
```
In the app: Settings -> Backend address (emulator: http://10.0.2.2:8787; phone on same Wi-Fi:
http://<PC-LAN-IP>:8787, debug build only) -> Test connection. Use https in production and add
Play Integrity attestation before release (device registration is open).

## Build the APK
Android Studio -> open this folder -> Sync -> Build > Build APK(s).
Then Settings -> Grant permissions.
