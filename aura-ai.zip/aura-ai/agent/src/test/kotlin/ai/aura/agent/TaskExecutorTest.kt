package ai.aura.agent

import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class TaskExecutorTest {
    private fun call(id: String, name: String, confirm: Boolean = false) =
        ToolCall(id, name, buildJsonObject { put("x", id) }, confirm)

    private class Fake(override val toolName: String, val result: ToolResult) : ToolHandler {
        var runs = 0
        override suspend fun execute(call: ToolCall): ToolResult { runs++; return result }
    }

    @Test fun runsSequentiallyAndReportsRealSuccess() = runTest {
        val a = Fake("open_app", ToolResult.Success("Opened YouTube"))
        val b = Fake("web_search", ToolResult.Success("3 results"))
        val out = TaskExecutor(listOf(a, b)) { true }.run(listOf(call("1", "open_app"), call("2", "web_search")))
        assertEquals(listOf(TaskStatus.SUCCEEDED, TaskStatus.SUCCEEDED), out.map { it.status })
    }

    @Test fun deniedConfirmationNeverExecutes() = runTest {
        val h = Fake("delete_media", ToolResult.Success("deleted"))
        val out = TaskExecutor(listOf(h)) { false }.run(listOf(call("1", "delete_media", confirm = true)))
        assertEquals(TaskStatus.DENIED, out[0].status)
        assertEquals(0, h.runs)
    }

    @Test fun failureSkipsRemainingSteps() = runTest {
        val bad = Fake("call_contact", ToolResult.Failure("no contact"))
        val next = Fake("open_app", ToolResult.Success("ok"))
        val out = TaskExecutor(listOf(bad, next)) { true }.run(listOf(call("1", "call_contact"), call("2", "open_app")))
        assertEquals(listOf(TaskStatus.FAILED, TaskStatus.SKIPPED), out.map { it.status })
        assertEquals(0, next.runs)
    }

    @Test fun unknownToolFailsInsteadOfRunning() = runTest {
        val out = TaskExecutor(emptyList()) { true }.run(listOf(call("1", "run_shell")))
        assertEquals(TaskStatus.FAILED, out[0].status)
    }

    @Test fun clarificationStopsAndSurfacesQuestion() = runTest {
        val h = Fake("call_contact", ToolResult.NeedsClarification("Which Rahul?"))
        val out = TaskExecutor(listOf(h)) { true }.run(listOf(call("1", "call_contact")))
        assertEquals(TaskStatus.NEEDS_INPUT, out[0].status)
        assertEquals("Which Rahul?", out[0].detail)
    }

    @Test fun missingPermissionIsNotReportedAsSuccess() = runTest {
        val h = Fake("search_media", ToolResult.MissingPermission("READ_MEDIA_VIDEO"))
        val out = TaskExecutor(listOf(h)) { true }.run(listOf(call("1", "search_media")))
        assertFalse(out[0].status == TaskStatus.SUCCEEDED)
    }

    @Test fun cancelDuringConfirmationStopsTask() = runTest {
        val h = Fake("draft_message", ToolResult.Success("drafted"))
        lateinit var ex: TaskExecutor
        ex = TaskExecutor(listOf(h)) { ex.cancel(); true }
        val out = ex.run(listOf(call("1", "draft_message", confirm = true)))
        assertEquals(TaskStatus.CANCELLED, out[0].status)
        assertEquals(0, h.runs)
    }
}
