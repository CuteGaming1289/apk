package ai.aura.agent

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/** A tool invocation already validated and allowlisted by the backend. */
@Serializable
data class ToolCall(
    val id: String,
    val name: String,
    val args: JsonObject,
    val requiresConfirmation: Boolean,
)

/** Outcome reported by a native tool handler. Success is only ever set by a handler. */
sealed interface ToolResult {
    data class Success(val message: String) : ToolResult
    data class NeedsClarification(val question: String) : ToolResult
    data class MissingPermission(val permission: String) : ToolResult
    data class Failure(val reason: String) : ToolResult
}

enum class TaskStatus { PENDING, AWAITING_CONFIRMATION, RUNNING, SUCCEEDED, FAILED, DENIED, CANCELLED, NEEDS_INPUT, SKIPPED }

data class TaskState(
    val call: ToolCall,
    val status: TaskStatus = TaskStatus.PENDING,
    val detail: String? = null,
)

/** Implemented natively in Android modules (contacts, media, reminders, ...). */
interface ToolHandler {
    val toolName: String
    suspend fun execute(call: ToolCall): ToolResult
}

/** Asks the user to approve a sensitive action. Returns true only on explicit approval. */
fun interface ConfirmationManager {
    suspend fun confirm(call: ToolCall): Boolean
}
