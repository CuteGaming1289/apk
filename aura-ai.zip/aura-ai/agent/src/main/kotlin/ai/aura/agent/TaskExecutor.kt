package ai.aura.agent

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Executes a planned list of tool calls strictly in order.
 *
 * Guarantees:
 *  - a call with no registered handler never runs (tool allowlist at the device too);
 *  - requiresConfirmation calls run only after explicit user approval;
 *  - SUCCEEDED is set only when the handler returned ToolResult.Success;
 *  - after a failure, denial, clarification or cancel, remaining steps are SKIPPED/CANCELLED,
 *    never silently run.
 */
class TaskExecutor(
    handlers: List<ToolHandler>,
    private val confirmations: ConfirmationManager,
) {
    private val byName = handlers.associateBy { it.toolName }
    private val _states = MutableStateFlow<List<TaskState>>(emptyList())
    val states: StateFlow<List<TaskState>> = _states.asStateFlow()

    @Volatile private var cancelled = false

    fun cancel() { cancelled = true }

    suspend fun run(calls: List<ToolCall>): List<TaskState> {
        cancelled = false
        _states.value = calls.map { TaskState(it) }
        var halted = false
        for ((i, call) in calls.withIndex()) {
            if (halted) { set(i, TaskStatus.SKIPPED, "Skipped because an earlier step did not complete"); continue }
            if (cancelled) { set(i, TaskStatus.CANCELLED, "Cancelled by user"); halted = true; continue }

            val handler = byName[call.name]
            if (handler == null) { set(i, TaskStatus.FAILED, "No handler for ${call.name}"); halted = true; continue }

            if (call.requiresConfirmation) {
                set(i, TaskStatus.AWAITING_CONFIRMATION)
                val approved = try { confirmations.confirm(call) } catch (e: CancellationException) { throw e }
                if (!approved) { set(i, TaskStatus.DENIED, "Not approved by user"); halted = true; continue }
                if (cancelled) { set(i, TaskStatus.CANCELLED, "Cancelled by user"); halted = true; continue }
            }

            set(i, TaskStatus.RUNNING)
            val result = try {
                handler.execute(call)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ToolResult.Failure(e.message ?: e::class.simpleName ?: "error")
            }
            when (result) {
                is ToolResult.Success -> set(i, TaskStatus.SUCCEEDED, result.message)
                is ToolResult.NeedsClarification -> { set(i, TaskStatus.NEEDS_INPUT, result.question); halted = true }
                is ToolResult.MissingPermission -> { set(i, TaskStatus.FAILED, "Permission needed: ${result.permission}"); halted = true }
                is ToolResult.Failure -> { set(i, TaskStatus.FAILED, result.reason); halted = true }
            }
        }
        return _states.value
    }

    private fun set(index: Int, status: TaskStatus, detail: String? = null) {
        _states.update { list -> list.mapIndexed { i, s -> if (i == index) s.copy(status = status, detail = detail) else s } }
    }
}
