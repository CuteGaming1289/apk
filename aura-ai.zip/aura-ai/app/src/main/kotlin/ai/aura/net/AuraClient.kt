package ai.aura.net

import ai.aura.agent.ToolCall
import ai.aura.data.Prefs
import ai.aura.tools.SearchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.HttpURLConnection
import java.net.URL
import java.time.OffsetDateTime
import java.util.TimeZone

class ApiException(val status: Int, val code: String) : Exception("HTTP $status: $code")

data class PlanResponse(val text: String, val toolCalls: List<ToolCall>)

/** Talks to the AURA backend. The Anthropic key never exists on the device. */
class AuraClient(private val prefs: Prefs) {

    suspend fun health(): Boolean = withContext(Dispatchers.IO) {
        try {
            val c = URL(prefs.backendUrl + "/health").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            c.responseCode == 200
        } catch (e: Exception) {
            false
        }
    }

    suspend fun plan(history: List<Pair<String, String>>, preferredLanguage: String?): PlanResponse {
        val body = buildJsonObject {
            put("messages", buildJsonArray {
                for ((role, content) in history) {
                    add(buildJsonObject { put("role", role); put("content", content) })
                }
            })
            put("timezone", TimeZone.getDefault().id)
            put("nowIso", OffsetDateTime.now().toString())
            if (preferredLanguage != null) put("preferredLanguage", preferredLanguage)
        }
        val o = post("/v1/agent/plan", body)
        val calls = (o["toolCalls"] as? JsonArray ?: JsonArray(emptyList())).map {
            val c = it.jsonObject
            ToolCall(
                id = c["id"]?.jsonPrimitive?.content ?: "",
                name = c["name"]?.jsonPrimitive?.content ?: "",
                args = c["args"]?.jsonObject ?: JsonObject(emptyMap()),
                requiresConfirmation = c["requiresConfirmation"]?.jsonPrimitive?.boolean ?: true,
            )
        }
        return PlanResponse(o["text"]?.jsonPrimitive?.content ?: "", calls)
    }

    suspend fun search(query: String): List<SearchResult> {
        val o = post("/v1/search", buildJsonObject { put("query", query) })
        return (o["results"] as? JsonArray ?: JsonArray(emptyList())).map {
            val r = it.jsonObject
            SearchResult(
                title = r["title"]?.jsonPrimitive?.content ?: "",
                url = r["url"]?.jsonPrimitive?.content ?: "",
                snippet = r["snippet"]?.jsonPrimitive?.content ?: "",
            )
        }
    }

    private suspend fun ensureToken(): String {
        val t = prefs.token
        if (t != null && System.currentTimeMillis() < prefs.tokenExpiryMs - 60_000) return t
        val o = rawPost("/v1/auth/device", buildJsonObject { put("deviceId", prefs.deviceId) }, null)
        val token = o["token"]?.jsonPrimitive?.content ?: throw ApiException(500, "no_token")
        val ttl = (o["expiresInSeconds"] as? JsonPrimitive)?.content?.toLongOrNull() ?: 3600L
        prefs.token = token
        prefs.tokenExpiryMs = System.currentTimeMillis() + ttl * 1000
        return token
    }

    private suspend fun post(path: String, body: JsonObject): JsonObject {
        return try {
            rawPost(path, body, ensureToken())
        } catch (e: ApiException) {
            if (e.status == 401) {
                prefs.token = null
                rawPost(path, body, ensureToken())
            } else throw e
        }
    }

    private suspend fun rawPost(path: String, body: JsonObject, token: String?): JsonObject =
        withContext(Dispatchers.IO) {
            val conn = URL(prefs.backendUrl + path).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 10_000
                conn.readTimeout = 30_000
                conn.doOutput = true
                conn.setRequestProperty("content-type", "application/json")
                if (token != null) conn.setRequestProperty("authorization", "Bearer $token")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) {
                    val err = try {
                        Json.parseToJsonElement(text).jsonObject["error"]?.jsonPrimitive?.content
                    } catch (e: Exception) { null }
                    throw ApiException(code, err ?: "http_$code")
                }
                Json.parseToJsonElement(text).jsonObject
            } finally {
                conn.disconnect()
            }
        }
}
