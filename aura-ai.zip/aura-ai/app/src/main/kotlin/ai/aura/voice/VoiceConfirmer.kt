package ai.aura.voice

import ai.aura.agent.ConfirmationManager
import ai.aura.agent.ToolCall
import ai.aura.data.Prefs

/** Spoken yes/no confirmation for when the app UI is not on screen. Default is "no". */
class VoiceConfirmer(
    private val speech: SpeechInput,
    private val speaker: Speaker,
    private val prefs: Prefs,
    private val describe: (ToolCall) -> String,
) : ConfirmationManager {

    override suspend fun confirm(call: ToolCall): Boolean {
        val q = describe(call).replace("\n", " ") + " Say yes to continue, or no to cancel."
        speaker.speak(q, Languages.speechTag(q, prefs.language))
        val r = speech.listenOnce(Languages.recognitionTag(prefs.language), onDevice = false, priority = false)
        return r is SpeechResult.Text && isYes(r.value)
    }

    companion object {
        private val no = listOf("no", "nope", "nahi", "nahin", "cancel", "stop", "mat", "नहीं", "नही", "मत")
        private val yes = listOf("yes", "yeah", "yep", "ok", "okay", "sure", "confirm", "haan", "han", "kar do", "kardo", "theek hai", "हाँ", "हां", "जी", "करो", "ठीक है")

        fun isYes(text: String): Boolean {
            val words = text.lowercase().split(Regex("[\\s,.!?]+")).filter { it.isNotEmpty() }
            val joined = words.joinToString(" ")
            if (no.any { it in words || (it.contains(' ') && joined.contains(it)) }) return false
            return yes.any { it in words || (it.contains(' ') && joined.contains(it)) }
        }
    }
}
