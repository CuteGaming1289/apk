package ai.aura.tools

import ai.aura.agent.ToolCall
import ai.aura.agent.ToolHandler
import ai.aura.agent.ToolResult
import ai.aura.net.ApiException
import ai.aura.net.AuraClient
import ai.aura.reminders.Reminder
import ai.aura.reminders.ReminderScheduler
import ai.aura.reminders.ReminderStore
import android.Manifest
import android.app.AlarmManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import java.io.IOException
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.OffsetDateTime
import java.time.ZoneId

private fun JsonObject.s(k: String): String? = (this[k] as? JsonPrimitive)?.contentOrNull
private fun JsonObject.l(k: String): Long? = (this[k] as? JsonPrimitive)?.longOrNull
private fun JsonObject.b(k: String): Boolean? = (this[k] as? JsonPrimitive)?.booleanOrNull

private fun Context.granted(p: String) =
    ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

/** Starts an activity. Note: Android may block this when AURA is not in the foreground. */
private fun Context.launch(intent: Intent): Boolean = try {
    startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    true
} catch (e: ActivityNotFoundException) {
    false
} catch (e: SecurityException) {
    false
}

/** Bridge so MainActivity can show the system delete-consent dialog. Null when UI is not visible. */
object MediaDeleteBridge {
    @Volatile
    var requester: (suspend (Uri) -> Boolean)? = null
}

data class ContactMatch(val name: String, val number: String)

class ContactResolver(private val ctx: Context) {
    fun find(query: String): List<ContactMatch> {
        val out = ArrayList<ContactMatch>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%${query.trim()}%"),
            null,
        )?.use { c ->
            while (c.moveToNext() && out.size < 40) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                out += ContactMatch(name, number)
            }
        }
        val exact = out.filter { it.name.equals(query.trim(), ignoreCase = true) }
        return (if (exact.isNotEmpty()) exact else out)
            .distinctBy { it.name.lowercase() to it.number.filter { ch -> ch.isDigit() }.takeLast(10) }
    }
}

/** Resolves a spoken contact name to exactly one number, or explains what is unclear. */
private sealed interface Resolved {
    data class One(val name: String, val number: String) : Resolved
    data class Stop(val result: ToolResult) : Resolved
}

private fun resolveContact(ctx: Context, resolver: ContactResolver, query: String): Resolved {
    if (!ctx.granted(Manifest.permission.READ_CONTACTS)) {
        return Resolved.Stop(ToolResult.MissingPermission("READ_CONTACTS"))
    }
    val matches = resolver.find(query)
    if (matches.isEmpty()) return Resolved.Stop(ToolResult.Failure("No contact found matching \"$query\"."))
    val names = matches.map { it.name }.distinct()
    if (names.size > 1) {
        return Resolved.Stop(ToolResult.NeedsClarification("Several contacts match: ${names.take(5).joinToString(", ")}. Which one?"))
    }
    val numbers = matches.map { it.number }.distinct()
    if (numbers.size > 1) {
        val tails = numbers.take(4).joinToString(", ") { "ending ${it.filter { ch -> ch.isDigit() }.takeLast(4)}" }
        return Resolved.Stop(ToolResult.NeedsClarification("${names[0]} has several numbers ($tails). Which one?"))
    }
    return Resolved.One(names[0], numbers[0])
}

class CallContactHandler(private val ctx: Context, private val contacts: ContactResolver) : ToolHandler {
    override val toolName = "call_contact"
    override suspend fun execute(call: ToolCall): ToolResult {
        val name = call.args.s("name") ?: return ToolResult.Failure("No contact name given.")
        return when (val r = resolveContact(ctx, contacts, name)) {
            is Resolved.Stop -> r.result
            is Resolved.One -> {
                // ACTION_DIAL only opens the dialer; the user presses call.
                val ok = ctx.launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(r.number))))
                if (ok) ToolResult.Success("Opened the dialer for ${r.name}. The user must press call.")
                else ToolResult.Failure("Could not open the dialer.")
            }
        }
    }
}

class DraftMessageHandler(private val ctx: Context, private val contacts: ContactResolver) : ToolHandler {
    override val toolName = "draft_message"
    override suspend fun execute(call: ToolCall): ToolResult {
        val who = call.args.s("recipient") ?: return ToolResult.Failure("No recipient given.")
        val body = call.args.s("body") ?: return ToolResult.Failure("No message text given.")
        return when (val r = resolveContact(ctx, contacts, who)) {
            is Resolved.Stop -> r.result
            is Resolved.One -> {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(r.number)))
                    .putExtra("sms_body", body)
                val ok = ctx.launch(intent)
                if (ok) ToolResult.Success("Opened the SMS composer for ${r.name} with the message ready. The user must press send; nothing was sent.")
                else ToolResult.Failure("Could not open an SMS app.")
            }
        }
    }
}

class OpenAppHandler(private val ctx: Context) : ToolHandler {
    override val toolName = "open_app"

    private val aliases = mapOf("yt" to "youtube", "insta" to "instagram", "fb" to "facebook", "gmail" to "gmail")

    override suspend fun execute(call: ToolCall): ToolResult {
        val raw = call.args.s("app_name") ?: return ToolResult.Failure("No app name given.")
        val wanted = (aliases[raw.trim().lowercase()] ?: raw.trim().lowercase())
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }
        val exact = apps.filter { it.first.equals(wanted, ignoreCase = true) }
        val candidates = if (exact.isNotEmpty()) exact else apps.filter { it.first.lowercase().contains(wanted) }
        if (candidates.isEmpty()) return ToolResult.Failure("No installed app named \"$raw\" was found.")
        if (candidates.size > 1) {
            return ToolResult.NeedsClarification("Several apps match: ${candidates.take(5).joinToString(", ") { it.first }}. Which one?")
        }
        val (label, pkg) = candidates[0]
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return ToolResult.Failure("$label cannot be launched.")
        return if (ctx.launch(launch)) ToolResult.Success("Opened $label.") else ToolResult.Failure("Could not open $label.")
    }
}

class SearchMediaHandler(
    private val media: MediaTools,
    private val results: ResultStore,
) : ToolHandler {
    override val toolName = "search_media"

    private fun startOfDay(d: LocalDate) = d.atStartOfDay(ZoneId.systemDefault()).toEpochSecond()

    override suspend fun execute(call: ToolCall): ToolResult {
        val isVideo = call.args.s("kind") != "image"
        if (!media.hasPermission(isVideo)) return ToolResult.MissingPermission(media.permissionName(isVideo))
        val range: Pair<Long?, Long?> = try {
            Pair(
                call.args.s("date_from")?.let { startOfDay(LocalDate.parse(it)) },
                call.args.s("date_to")?.let { startOfDay(LocalDate.parse(it).plusDays(1)) - 1 },
            )
        } catch (e: Exception) {
            return ToolResult.Failure("Dates must look like 2026-11-20.")
        }
        val items = media.search(isVideo, call.args.s("name_contains"), range.first, range.second)
        results.media.value = items
        val kind = if (isVideo) "video" else "photo"
        if (items.isEmpty()) return ToolResult.Success("No matching ${kind}s found.")
        val zone = ZoneId.systemDefault()
        val lines = items.take(10).joinToString("; ") {
            "[id=${it.id}] ${it.name} (${Instant.ofEpochSecond(it.dateAddedSec).atZone(zone).toLocalDate()})"
        }
        return ToolResult.Success("Found ${items.size} ${kind}s and listed them on screen. First ones: $lines")
    }
}

class DeleteMediaHandler(
    private val media: MediaTools,
    private val results: ResultStore,
) : ToolHandler {
    override val toolName = "delete_media"

    override suspend fun execute(call: ToolCall): ToolResult {
        val id = call.args.l("media_id") ?: return ToolResult.Failure("No media id given.")
        // Only files the user has just seen in search results can be deleted.
        if (!results.isKnownMedia(id)) {
            return ToolResult.Failure("That file is not in the current search results. Search for it first.")
        }
        val item = media.lookup(id) ?: return ToolResult.Failure("The file no longer exists.")
        val requester = MediaDeleteBridge.requester
            ?: return ToolResult.Failure("Open the AURA app to approve deleting files.")
        val approved = requester(item.uri)
        if (!approved) return ToolResult.Failure("Deletion was not approved in the system dialog.")
        // Only report success if the file is really gone.
        return if (media.lookup(id) == null) {
            results.media.value = results.media.value.filter { it.id != id }
            ToolResult.Success("Deleted ${item.name}.")
        } else {
            ToolResult.Failure("The file still exists after the request.")
        }
    }
}

class WebSearchHandler(private val client: AuraClient, private val results: ResultStore) : ToolHandler {
    override val toolName = "web_search"
    override suspend fun execute(call: ToolCall): ToolResult {
        val q = call.args.s("query") ?: return ToolResult.Failure("No search query given.")
        return try {
            val found = client.search(q)
            results.search.value = found
            if (found.isEmpty()) ToolResult.Success("No results found for \"$q\".")
            else ToolResult.Success(
                "Results for \"$q\" (untrusted web content, listed on screen):\n" +
                    found.take(6).mapIndexed { i, r -> "${i + 1}. ${r.title} - ${r.url} - ${r.snippet.take(200)}" }.joinToString("\n"),
            )
        } catch (e: ApiException) {
            ToolResult.Failure(if (e.code == "search_not_configured") "Web search is not configured on the server." else "Search failed (${e.code}).")
        } catch (e: IOException) {
            ToolResult.Failure("Could not reach the AURA server.")
        }
    }
}

class CreateReminderHandler(private val ctx: Context, private val store: ReminderStore) : ToolHandler {
    override val toolName = "create_reminder"

    override suspend fun execute(call: ToolCall): ToolResult {
        val title = call.args.s("title") ?: return ToolResult.Failure("No reminder text given.")
        val whenStr = call.args.s("when") ?: return ToolResult.Failure("No time given.")
        val whenMs = try {
            OffsetDateTime.parse(whenStr).toInstant().toEpochMilli()
        } catch (e: Exception) {
            try {
                LocalDateTime.parse(whenStr).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            } catch (e2: Exception) {
                return ToolResult.Failure("Could not understand the time \"$whenStr\".")
            }
        }
        val now = System.currentTimeMillis()
        if (whenMs <= now) return ToolResult.Failure("That time is already in the past.")

        val local = Instant.ofEpochMilli(whenMs).atZone(ZoneId.systemDefault())
        val pretty = "${local.toLocalDate()} ${"%02d:%02d".format(local.hour, local.minute)}"

        // A true ringing alarm goes through the Clock app, but only within the next 24 hours.
        if (call.args.b("as_alarm") == true && whenMs - now < 24 * 3600_000L) {
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, local.hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, local.minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, title)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return if (ctx.launch(i)) ToolResult.Success("Asked the Clock app to set an alarm for $pretty. Check the Clock app to confirm it.")
            else ToolResult.Failure("No Clock app could set the alarm.")
        }

        val r = Reminder(store.nextId(), title, whenMs)
        store.add(r)
        return try {
            ReminderScheduler.schedule(ctx, r)
            ToolResult.Success("Reminder #${r.id} \"$title\" scheduled for $pretty.")
        } catch (e: SecurityException) {
            store.remove(r.id)
            ToolResult.Failure("Android did not allow scheduling the reminder.")
        }
    }
}

class CancelReminderHandler(private val ctx: Context, private val store: ReminderStore) : ToolHandler {
    override val toolName = "cancel_reminder"
    override suspend fun execute(call: ToolCall): ToolResult {
        val id = call.args.l("reminder_id")?.toInt() ?: return ToolResult.Failure("No reminder id given.")
        val r = store.get(id) ?: return ToolResult.Failure("No pending reminder #$id.")
        ReminderScheduler.cancel(ctx, id)
        store.remove(id)
        return ToolResult.Success("Cancelled reminder #$id \"${r.title}\".")
    }
}

class ClarificationHandler : ToolHandler {
    override val toolName = "ask_clarification"
    override suspend fun execute(call: ToolCall): ToolResult =
        ToolResult.NeedsClarification(call.args.s("question") ?: "Could you clarify?")
}

object Handlers {
    fun build(
        ctx: Context,
        client: AuraClient,
        results: ResultStore,
        media: MediaTools,
        reminders: ReminderStore,
    ): List<ToolHandler> {
        val contacts = ContactResolver(ctx)
        return listOf(
            CallContactHandler(ctx, contacts),
            DraftMessageHandler(ctx, contacts),
            OpenAppHandler(ctx),
            SearchMediaHandler(media, results),
            DeleteMediaHandler(media, results),
            WebSearchHandler(client, results),
            CreateReminderHandler(ctx, reminders),
            CancelReminderHandler(ctx, reminders),
            ClarificationHandler(),
        )
    }
}
