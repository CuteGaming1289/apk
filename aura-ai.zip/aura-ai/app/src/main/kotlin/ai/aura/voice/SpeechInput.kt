package ai.aura.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

sealed interface SpeechResult {
    data class Text(val value: String) : SpeechResult
    data object NoMatch : SpeechResult
    data object Interrupted : SpeechResult
    data class Error(val code: Int) : SpeechResult
}

/**
 * One-shot speech recognition. Calls are serialized so the background wake-word loop
 * and push-to-talk never hold the microphone at once; a priority call interrupts the
 * current listen.
 */
class SpeechInput(private val context: Context) {
    private val lock = Mutex()
    private var interruptCurrent: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    /** True when an on-device recognizer exists (Android 13+ and a downloaded speech pack). */
    fun onDeviceAvailable(): Boolean =
        Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)

    fun interrupt() {
        interruptCurrent?.invoke()
    }

    suspend fun listenOnce(
        languageTag: String?,
        onDevice: Boolean = false,
        priority: Boolean = false,
        onPartial: (String) -> Unit = {},
    ): SpeechResult {
        if (priority) interrupt()
        return lock.withLock {
            withContext(Dispatchers.Main.immediate) { recognize(languageTag, onDevice, onPartial) }
        }
    }

    private suspend fun recognize(
        languageTag: String?,
        onDevice: Boolean,
        onPartial: (String) -> Unit,
    ): SpeechResult = suspendCancellableCoroutine { cont ->
        val recognizer: SpeechRecognizer? = when {
            onDevice ->
                if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                else null
            SpeechRecognizer.isRecognitionAvailable(context) -> SpeechRecognizer.createSpeechRecognizer(context)
            else -> null
        }
        if (recognizer == null) {
            cont.resume(SpeechResult.Error(-1))
            return@suspendCancellableCoroutine
        }

        var done = false
        fun finish(r: SpeechResult) {
            if (done) return
            done = true
            interruptCurrent = null
            try { recognizer.destroy() } catch (_: Exception) {}
            if (cont.isActive) cont.resume(r)
        }
        interruptCurrent = { finish(SpeechResult.Interrupted) }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) onPartial(t)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                finish(if (t.isNullOrBlank()) SpeechResult.NoMatch else SpeechResult.Text(t))
            }
            override fun onError(error: Int) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> finish(SpeechResult.NoMatch)
                    else -> finish(SpeechResult.Error(error))
                }
            }
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        if (languageTag != null) intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        if (onDevice) intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            finish(SpeechResult.Error(-2))
        }

        cont.invokeOnCancellation {
            main.post {
                done = true
                interruptCurrent = null
                try { recognizer.cancel(); recognizer.destroy() } catch (_: Exception) {}
            }
        }
    }
}
