package ai.aura.ui

import ai.aura.AgentEngine
import ai.aura.AuraApp
import ai.aura.agent.TaskStatus
import ai.aura.tools.MediaItem
import ai.aura.voice.Languages
import ai.aura.voice.ListeningService
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Size
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

val Black = Color(0xFF000000)
val Navy = Color(0xFF0A1428)
val Blue = Color(0xFF2F6BFF)
val Cyan = Color(0xFF22D3EE)
private val Dim = Color.White.copy(alpha = 0.65f)

@Composable
fun AuraRoot(
    app: AuraApp,
    onRequestPermissions: () -> Unit,
    onToggleBackground: (Boolean) -> String?,
) {
    var tab by remember { mutableStateOf(0) }
    val confirm by app.engine.pendingConfirmation.collectAsState()

    Column(Modifier.fillMaxSize().background(Black).systemBarsPadding().imePadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> HomeScreen(app)
                1 -> TasksScreen(app)
                else -> SettingsScreen(app, onRequestPermissions, onToggleBackground)
            }
        }
        Row(Modifier.fillMaxWidth().background(Navy)) {
            listOf("Home", "Automation", "Settings").forEachIndexed { i, label ->
                TextButton(onClick = { tab = i }, modifier = Modifier.weight(1f)) {
                    Text(label, color = if (tab == i) Cyan else Dim)
                }
            }
        }
    }

    confirm?.let { req ->
        AlertDialog(
            onDismissRequest = { req.answer.complete(false) },
            title = { Text("Please confirm") },
            text = { Text(req.description) },
            confirmButton = { TextButton(onClick = { req.answer.complete(true) }) { Text("Yes") } },
            dismissButton = { TextButton(onClick = { req.answer.complete(false) }) { Text("No") } },
        )
    }
}

@Composable
fun Orb(status: AgentEngine.Status, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val pulse by t.animateFloat(
        initialValue = 0.9f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            tween(if (status == AgentEngine.Status.THINKING) 600 else 1300), RepeatMode.Reverse,
        ),
        label = "pulse",
    )
    val scale = if (status == AgentEngine.Status.IDLE) 1f else pulse
    val inner = when (status) {
        AgentEngine.Status.LISTENING -> Cyan
        AgentEngine.Status.THINKING -> Color(0xFF8B5CF6)
        AgentEngine.Status.SPEAKING -> Blue
        AgentEngine.Status.IDLE -> Color(0xFF3B82F6)
    }
    Canvas(modifier) {
        val r = size.minDimension / 2f * scale
        drawCircle(
            brush = Brush.radialGradient(listOf(inner, Blue, Navy), center = Offset(center.x, center.y), radius = r),
            radius = r,
        )
    }
}

@Composable
fun HomeScreen(app: AuraApp) {
    val e = app.engine
    val context = LocalContext.current
    val status by e.status.collectAsState()
    val chat by e.chat.collectAsState()
    val partial by e.partialSpeech.collectAsState()
    val search by app.results.search.collectAsState()
    val media by app.results.media.collectAsState()
    var input by remember { mutableStateOf("") }

    fun send() {
        if (input.isNotBlank()) { e.submitText(input); input = "" }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Text("AURA AI", style = MaterialTheme.typography.headlineMedium, color = Cyan, modifier = Modifier.padding(top = 12.dp))
                Text("Your World. Your Intelligence.", color = Dim)
                Orb(status, Modifier.padding(vertical = 20.dp).size(140.dp))
                Text(
                    when (status) {
                        AgentEngine.Status.IDLE -> "Ready"
                        AgentEngine.Status.LISTENING -> if (partial.isBlank()) "Listening..." else partial
                        AgentEngine.Status.THINKING -> "Thinking..."
                        AgentEngine.Status.SPEAKING -> "Speaking..."
                    },
                    color = Dim,
                )
                Row(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Open YouTube", "Search technology news", "Remind me in an hour").forEach { q ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Navy),
                            modifier = Modifier.weight(1f).clickable { e.submitText(q) },
                        ) { Text(q, color = Color.White, modifier = Modifier.padding(10.dp)) }
                    }
                }
            }
            items(chat) { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.background(if (m.fromUser) Blue else Navy, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
                    ) { Text(m.text, color = Color.White) }
                }
            }
            if (search.isNotEmpty()) {
                item { Text("Search results", color = Cyan, modifier = Modifier.padding(top = 12.dp)) }
                items(search) { r ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Navy),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        },
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(r.title, color = Color.White)
                            Text(r.url, color = Cyan, maxLines = 1)
                            Text(r.snippet, color = Dim, maxLines = 2)
                        }
                    }
                }
            }
            if (media.isNotEmpty()) {
                item { Text("Media found", color = Cyan, modifier = Modifier.padding(top = 12.dp)) }
                items(media) { m -> MediaRow(m) { e.submitText("Delete the file named ${m.name} (media id ${m.id})") } }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type or tap the mic") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                singleLine = true,
            )
            TextButton(onClick = { send() }) { Text("Send", color = Cyan) }
            Box(
                Modifier.size(52.dp).background(if (status == AgentEngine.Status.LISTENING) Cyan else Blue, CircleShape)
                    .clickable { if (status == AgentEngine.Status.IDLE) e.startVoice() else e.stop() },
                contentAlignment = Alignment.Center,
            ) { Text(if (status == AgentEngine.Status.IDLE) "🎤" else "■", color = Color.White) }
        }
    }
}

@Composable
private fun MediaRow(m: MediaItem, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    var bmp by remember(m.id) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(m.id) {
        bmp = withContext(Dispatchers.IO) {
            try { ctx.contentResolver.loadThumbnail(m.uri, Size(160, 160), null).asImageBitmap() } catch (e: Exception) { null }
        }
    }
    Card(colors = CardDefaults.cardColors(containerColor = Navy), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            val b = bmp
            if (b != null) Image(b, contentDescription = null, modifier = Modifier.size(56.dp))
            else Box(Modifier.size(56.dp).background(Black))
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(m.name, color = Color.White, maxLines = 1)
                Text("${m.sizeBytes / 1024} KB", color = Dim)
            }
            TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFFF6B6B)) }
        }
    }
}

@Composable
fun TasksScreen(app: AuraApp) {
    val e = app.engine
    val running by e.tasks.collectAsState()
    val history by e.taskHistory.collectAsState()
    val active = setOf(TaskStatus.PENDING, TaskStatus.AWAITING_CONFIRMATION, TaskStatus.RUNNING, TaskStatus.NEEDS_INPUT)
    val failed = setOf(TaskStatus.FAILED, TaskStatus.DENIED, TaskStatus.CANCELLED, TaskStatus.SKIPPED)

    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item { Text("Automation", style = MaterialTheme.typography.headlineSmall, color = Cyan) }
        val now = running.filter { it.status in active }
        item { Text("Running and pending approval", color = Dim, modifier = Modifier.padding(top = 12.dp)) }
        if (now.isEmpty()) item { Text("Nothing running.", color = Color.White) }
        items(now) { t ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${t.call.name}: ${t.status}", color = Color.White, modifier = Modifier.weight(1f))
                TextButton(onClick = { e.stop() }) { Text("Cancel", color = Color(0xFFFF6B6B)) }
            }
        }
        item { Text("Completed", color = Dim, modifier = Modifier.padding(top = 16.dp)) }
        items(history.filter { it.status == TaskStatus.SUCCEEDED }.reversed()) { t ->
            Text("✓ ${t.call.name} — ${t.detail ?: ""}", color = Color.White, modifier = Modifier.padding(vertical = 2.dp))
        }
        item { Text("Failed or stopped", color = Dim, modifier = Modifier.padding(top = 16.dp)) }
        items(history.filter { it.status in failed }.reversed()) { t ->
            Text("✗ ${t.call.name} (${t.status}) — ${t.detail ?: ""}", color = Color(0xFFFF9B9B), modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}

@Composable
fun SettingsScreen(
    app: AuraApp,
    onRequestPermissions: () -> Unit,
    onToggleBackground: (Boolean) -> String?,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var url by remember { mutableStateOf(app.prefs.backendUrl) }
    var lang by remember { mutableStateOf(app.prefs.language) }
    var bg by remember { mutableStateOf(ListeningService.running) }
    var note by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Text("Settings", style = MaterialTheme.typography.headlineSmall, color = Cyan)

            Text("Backend address", color = Dim, modifier = Modifier.padding(top = 16.dp))
            OutlinedTextField(value = url, onValueChange = { url = it }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row {
                TextButton(onClick = { app.prefs.backendUrl = url; app.prefs.token = null; note = "Saved." }) { Text("Save", color = Cyan) }
                TextButton(onClick = {
                    app.prefs.backendUrl = url
                    scope.launch { note = if (app.client.health()) "Server reachable." else "Cannot reach the server." }
                }) { Text("Test connection", color = Cyan) }
            }

            Text("Permissions", color = Dim, modifier = Modifier.padding(top = 12.dp))
            Button(onClick = onRequestPermissions, colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                Text("Grant microphone, contacts, media, notifications")
            }

            Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Background listening (\"Hey AURA\")", color = Color.White)
                    Text("Experimental. Uses on-device speech recognition (Android 13+). Shows a notification while the mic is on.", color = Dim)
                }
                Switch(checked = bg, onCheckedChange = { want ->
                    val err = onToggleBackground(want)
                    if (err != null) note = err else bg = want
                })
            }
            TextButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("Battery optimization settings", color = Cyan) }

            Text("Language", color = Dim, modifier = Modifier.padding(top = 12.dp))
        }
        items(Languages.options) { o ->
            Row(Modifier.fillMaxWidth().clickable { lang = o.tag; app.prefs.language = o.tag }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = lang == o.tag, onClick = { lang = o.tag; app.prefs.language = o.tag })
                Text(o.label, color = Color.White)
            }
        }
        item {
            Text("Whether a language works depends on the speech and voice packs installed on your phone.", color = Dim, modifier = Modifier.padding(top = 4.dp))
            Text("Privacy", color = Dim, modifier = Modifier.padding(top = 16.dp))
            Button(
                onClick = { app.engine.clearConversation(); note = "Conversation cleared." },
                colors = ButtonDefaults.buttonColors(containerColor = Navy),
            ) { Text("Clear conversation and results") }
            if (note.isNotEmpty()) Text(note, color = Cyan, modifier = Modifier.padding(top = 12.dp))
        }
    }
}
