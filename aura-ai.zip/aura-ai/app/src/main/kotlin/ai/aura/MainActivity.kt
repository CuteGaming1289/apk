package ai.aura

import ai.aura.tools.MediaDeleteBridge
import ai.aura.ui.AuraRoot
import ai.aura.ui.Black
import ai.aura.ui.Cyan
import ai.aura.ui.Navy
import ai.aura.voice.ListeningService
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred

class MainActivity : ComponentActivity() {

    private var deleteResult: CompletableDeferred<Boolean>? = null

    private val deleteLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            deleteResult?.complete(r.resultCode == RESULT_OK)
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AuraApp

        // Lets the delete tool show Android's own consent dialog while the UI is visible.
        MediaDeleteBridge.requester = { uri ->
            if (Build.VERSION.SDK_INT >= 30) {
                val d = CompletableDeferred<Boolean>()
                deleteResult = d
                val pi = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                d.await()
            } else false
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Black, surface = Navy)) {
                AuraRoot(
                    app = app,
                    onRequestPermissions = { requestAllPermissions() },
                    onToggleBackground = { enable -> toggleBackground(app, enable) },
                )
            }
        }
    }

    override fun onDestroy() {
        MediaDeleteBridge.requester = null
        super.onDestroy()
    }

    private fun requestAllPermissions() {
        val wanted = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.POST_NOTIFICATIONS)
                add(Manifest.permission.READ_MEDIA_VIDEO)
                add(Manifest.permission.READ_MEDIA_IMAGES)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (wanted.isNotEmpty()) permLauncher.launch(wanted.toTypedArray())
    }

    /** Returns an error message, or null on success. */
    private fun toggleBackground(app: AuraApp, enable: Boolean): String? {
        if (!enable) {
            startService(Intent(this, ListeningService::class.java).setAction(ListeningService.ACTION_STOP))
            return null
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "Grant the microphone permission first."
        }
        if (!app.speech.onDeviceAvailable()) {
            return "Background wake word needs Android 13+ with an on-device speech pack. " +
                "It is disabled so audio is never sent to the cloud while idle."
        }
        ContextCompat.startForegroundService(this, Intent(this, ListeningService::class.java))
        return null
    }
}
