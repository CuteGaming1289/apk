package ai.aura

import ai.aura.data.Prefs
import ai.aura.net.AuraClient
import ai.aura.reminders.ReminderStore
import ai.aura.tools.Handlers
import ai.aura.tools.MediaTools
import ai.aura.tools.ResultStore
import ai.aura.voice.Speaker
import ai.aura.voice.SpeechInput
import android.app.Application

/** Simple manual dependency graph shared by the UI and the background service. */
class AuraApp : Application() {
    val prefs by lazy { Prefs(this) }
    val client by lazy { AuraClient(prefs) }
    val speaker by lazy { Speaker(this) }
    val speech by lazy { SpeechInput(this) }
    val results by lazy { ResultStore() }
    private val media by lazy { MediaTools(this) }
    val engine by lazy {
        AgentEngine(
            prefs, client, speaker, speech, results, media,
            Handlers.build(this, client, results, media, ReminderStore(this)),
        )
    }
}
