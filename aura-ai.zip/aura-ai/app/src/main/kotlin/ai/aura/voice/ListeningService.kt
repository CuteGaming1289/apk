package ai.aura.voice

import ai.aura.AgentEngine
import ai.aura.AuraApp
import ai.aura.MainActivity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground microphone service for "Hey AURA".
 *
 * Wake detection runs through the ON-DEVICE speech recognizer (Android 13+). It is a
 * best-effort stand-in for a dedicated wake-word engine such as Porcupine: accuracy and
 * battery use are worse, and some devices play a start/stop sound. Idle audio is never
 * sent to the cloud; only the command spoken after the wake phrase uses the normal
 * recognizer and the text goes to the backend.
 *
 * Android may block launching other apps while AURA is in the background.
 */
class ListeningService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
        running = true
        if (loop == null) loop = scope.launch { listenLoop() }
        return START_NOT_STICKY
    }

    private suspend fun listenLoop() {
        val app = application as AuraApp
        val engine = app.engine
        if (!app.speech.onDeviceAvailable()) {
            shutdown()
            return
        }
        val confirmer = VoiceConfirmer(app.speech, app.speaker, app.prefs) { engine.describe(it) }
        var errors = 0
        while (scope.isActive) {
            engine.status.first { it == AgentEngine.Status.IDLE }
            when (val r = app.speech.listenOnce(null, onDevice = true)) {
                is SpeechResult.Text -> {
                    errors = 0
                    val rest = WakePhrase.afterWake(r.value)
                    if (rest != null) engine.wake(confirmer, rest.ifBlank { null })
                }
                SpeechResult.NoMatch -> { errors = 0; delay(200) }
                SpeechResult.Interrupted -> delay(1500)
                is SpeechResult.Error -> {
                    errors++
                    if (errors >= 8) { shutdown(); return }
                    delay(minOf(1000L * errors, 8000L))
                }
            }
        }
    }

    private fun shutdown() {
        loop?.cancel()
        loop = null
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "AURA listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListeningService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("AURA is listening")
            .setContentText("Microphone is on. Say \"Hey AURA\". Tap Stop to turn off.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Stop", stop).build())
            .build()
    }

    companion object {
        const val ACTION_STOP = "ai.aura.action.STOP_LISTENING"
        private const val CHANNEL_ID = "aura_listening"
        private const val NOTIFICATION_ID = 1001
        @Volatile var running = false
            private set
    }
}

object WakePhrase {
    private val variants = listOf("hey aura", "hey ora", "hey aurora", "hey ara", "hi aura", "hey áura", "ok aura", "हे ऑरा", "हे आरा", "हे ओरा")

    /** Returns null if the wake phrase is absent, else the command after it (possibly empty). */
    fun afterWake(heard: String): String? {
        val lower = heard.lowercase().trim()
        for (v in variants) {
            val i = lower.indexOf(v)
            if (i >= 0) return heard.substring(i + v.length).trim(' ', ',', '.', '!')
        }
        return null
    }
}
