package ai.aura.voice

import java.util.Locale

data class LangOption(val tag: String, val label: String)

object Languages {
    // Selectable preferences. Whether recognition/TTS actually works for a language
    // depends on the speech and voice packs installed on the phone.
    val options = listOf(
        LangOption("auto", "Automatic"),
        LangOption("en-IN", "English (India)"),
        LangOption("en-US", "English (US)"),
        LangOption("hi-IN", "Hindi / Hinglish"),
        LangOption("ur-IN", "Urdu"),
        LangOption("bn-IN", "Bengali"),
        LangOption("mr-IN", "Marathi"),
        LangOption("gu-IN", "Gujarati"),
        LangOption("pa-IN", "Punjabi"),
        LangOption("ta-IN", "Tamil"),
        LangOption("te-IN", "Telugu"),
        LangOption("kn-IN", "Kannada"),
        LangOption("ml-IN", "Malayalam"),
        LangOption("ar-SA", "Arabic"),
        LangOption("fr-FR", "French"),
        LangOption("de-DE", "German"),
        LangOption("es-ES", "Spanish"),
        LangOption("pt-BR", "Portuguese"),
        LangOption("ru-RU", "Russian"),
        LangOption("zh-CN", "Chinese"),
        LangOption("ja-JP", "Japanese"),
        LangOption("ko-KR", "Korean"),
    )

    /** Language tag for the recognizer, or null to let the system choose. */
    fun recognitionTag(pref: String): String? = if (pref == "auto") null else pref

    /** Picks a TTS language: the user's preference, else a guess from the script of [text]. */
    fun speechTag(text: String, pref: String): String {
        if (pref != "auto") return pref
        for (ch in text) {
            val c = ch.code
            when {
                c in 0x0900..0x097F -> return "hi-IN"
                c in 0x0980..0x09FF -> return "bn-IN"
                c in 0x0A00..0x0A7F -> return "pa-IN"
                c in 0x0A80..0x0AFF -> return "gu-IN"
                c in 0x0B80..0x0BFF -> return "ta-IN"
                c in 0x0C00..0x0C7F -> return "te-IN"
                c in 0x0C80..0x0CFF -> return "kn-IN"
                c in 0x0D00..0x0D7F -> return "ml-IN"
                c in 0x0600..0x06FF -> return "ar-SA"
                c in 0x0400..0x04FF -> return "ru-RU"
                c in 0x3040..0x30FF -> return "ja-JP"
                c in 0xAC00..0xD7AF -> return "ko-KR"
                c in 0x4E00..0x9FFF -> return "zh-CN"
            }
        }
        return Locale.getDefault().toLanguageTag()
    }
}
