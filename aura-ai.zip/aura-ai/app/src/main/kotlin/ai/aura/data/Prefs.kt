package ai.aura.data

import android.content.Context
import java.util.UUID

/** Small local settings store. Holds no API keys: those live only on the backend. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("aura", Context.MODE_PRIVATE)

    var backendUrl: String
        get() = sp.getString("backendUrl", "http://10.0.2.2:8787") ?: "http://10.0.2.2:8787"
        set(v) { sp.edit().putString("backendUrl", v.trim().trimEnd('/')).apply() }

    /** Random per-install id used to obtain a backend token. 32 hex chars. */
    val deviceId: String
        get() {
            val existing = sp.getString("deviceId", null)
            if (existing != null) return existing
            val id = UUID.randomUUID().toString().replace("-", "")
            sp.edit().putString("deviceId", id).apply()
            return id
        }

    var token: String?
        get() = sp.getString("token", null)
        set(v) { sp.edit().putString("token", v).apply() }

    var tokenExpiryMs: Long
        get() = sp.getLong("tokenExpiryMs", 0L)
        set(v) { sp.edit().putLong("tokenExpiryMs", v).apply() }

    /** "auto" or a BCP-47 tag such as "hi-IN". */
    var language: String
        get() = sp.getString("language", "auto") ?: "auto"
        set(v) { sp.edit().putString("language", v).apply() }
}
