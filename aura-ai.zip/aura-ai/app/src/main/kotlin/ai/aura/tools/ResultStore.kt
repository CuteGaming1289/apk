package ai.aura.tools

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.flow.MutableStateFlow

data class SearchResult(val title: String, val url: String, val snippet: String)

data class MediaItem(
    val id: Long,
    val name: String,
    val dateAddedSec: Long,
    val sizeBytes: Long,
    val isVideo: Boolean,
) {
    val uri: Uri
        get() = ContentUris.withAppendedId(
            if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            id,
        )
}

/** Latest results shown in the UI. Delete is only allowed for items listed in [media]. */
class ResultStore {
    val media = MutableStateFlow<List<MediaItem>>(emptyList())
    val search = MutableStateFlow<List<SearchResult>>(emptyList())

    fun isKnownMedia(id: Long): Boolean = media.value.any { it.id == id }
}
