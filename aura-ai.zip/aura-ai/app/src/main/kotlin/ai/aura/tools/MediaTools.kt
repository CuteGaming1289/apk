package ai.aura.tools

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.ContextCompat

class MediaTools(private val ctx: Context) {

    fun hasPermission(isVideo: Boolean): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) {
            if (isVideo) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_MEDIA_IMAGES
        } else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
    }

    fun permissionName(isVideo: Boolean): String =
        if (Build.VERSION.SDK_INT >= 33) (if (isVideo) "READ_MEDIA_VIDEO" else "READ_MEDIA_IMAGES") else "READ_EXTERNAL_STORAGE"

    private fun collection(isVideo: Boolean) =
        if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    private val projection = arrayOf(
        MediaStore.MediaColumns._ID,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.DATE_ADDED,
        MediaStore.MediaColumns.SIZE,
    )

    fun search(isVideo: Boolean, nameContains: String?, fromSec: Long?, toSec: Long?, limit: Int = 30): List<MediaItem> {
        val clauses = ArrayList<String>()
        val args = ArrayList<String>()
        if (!nameContains.isNullOrBlank()) {
            clauses += "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
            args += "%${nameContains.trim()}%"
        }
        if (fromSec != null) {
            clauses += "${MediaStore.MediaColumns.DATE_ADDED} >= ?"
            args += fromSec.toString()
        }
        if (toSec != null) {
            clauses += "${MediaStore.MediaColumns.DATE_ADDED} <= ?"
            args += toSec.toString()
        }
        val out = ArrayList<MediaItem>()
        ctx.contentResolver.query(
            collection(isVideo),
            projection,
            if (clauses.isEmpty()) null else clauses.joinToString(" AND "),
            if (args.isEmpty()) null else args.toTypedArray(),
            "${MediaStore.MediaColumns.DATE_ADDED} DESC",
        )?.use { c ->
            while (c.moveToNext() && out.size < limit) {
                out += MediaItem(c.getLong(0), c.getString(1) ?: "(unnamed)", c.getLong(2), c.getLong(3), isVideo)
            }
        }
        return out
    }

    /** Finds an item by id in the video collection, then the image collection. */
    fun lookup(id: Long): MediaItem? {
        for (isVideo in listOf(true, false)) {
            val uri = ContentUris.withAppendedId(collection(isVideo), id)
            ctx.contentResolver.query(uri, projection, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    return MediaItem(c.getLong(0), c.getString(1) ?: "(unnamed)", c.getLong(2), c.getLong(3), isVideo)
                }
            }
        }
        return null
    }
}
