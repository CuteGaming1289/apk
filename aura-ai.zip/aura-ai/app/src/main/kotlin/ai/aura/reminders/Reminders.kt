package ai.aura.reminders

import ai.aura.MainActivity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class Reminder(val id: Int, val title: String, val whenMs: Long)

/** Persists reminders so they can be listed, cancelled and rescheduled after reboot. */
class ReminderStore(context: Context) {
    private val sp = context.getSharedPreferences("aura_reminders", Context.MODE_PRIVATE)

    fun all(): List<Reminder> {
        val arr = try { JSONArray(sp.getString("items", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Reminder(o.getInt("id"), o.getString("title"), o.getLong("whenMs"))
        }
    }

    private fun save(list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("title", it.title).put("whenMs", it.whenMs)) }
        sp.edit().putString("items", arr.toString()).apply()
    }

    fun nextId(): Int {
        val n = sp.getInt("nextId", 1)
        sp.edit().putInt("nextId", n + 1).apply()
        return n
    }

    fun add(r: Reminder) = save(all() + r)
    fun remove(id: Int) = save(all().filter { it.id != id })
    fun get(id: Int): Reminder? = all().firstOrNull { it.id == id }
}

object ReminderScheduler {
    private fun pending(ctx: Context, id: Int, title: String?, flags: Int): PendingIntent? {
        val i = Intent(ctx, ReminderReceiver::class.java)
        if (title != null) i.putExtra("id", id).putExtra("title", title)
        return PendingIntent.getBroadcast(ctx, id, i, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        // setAlarmClock is exact and does not need the exact-alarm permission.
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.whenMs, show), pending(ctx, r.id, r.title, PendingIntent.FLAG_UPDATE_CURRENT)!!)
    }

    fun cancel(ctx: Context, id: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, id, null, PendingIntent.FLAG_NO_CREATE) ?: return
        am.cancel(pi)
        pi.cancel()
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val title = intent.getStringExtra("title") ?: "Reminder"
        ReminderStore(context).remove(id)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("aura_reminders", "AURA reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = android.app.Notification.Builder(context, "aura_reminders")
            .setContentTitle("AURA reminder")
            .setContentText(title)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(10_000 + id, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val now = System.currentTimeMillis()
        val store = ReminderStore(context)
        for (r in store.all()) {
            if (r.whenMs > now) ReminderScheduler.schedule(context, r) else store.remove(r.id)
        }
    }
}
