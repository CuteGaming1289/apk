import { createHmac, timingSafeEqual } from "node:crypto";

// Stateless signed bearer tokens: base64url(payload).base64url(hmac).
// The device id is bound into the token so rate limits follow the install.

const b64 = (buf) => Buffer.from(buf).toString("base64url");

export function issueToken(secret, deviceId, ttlSeconds, now = Date.now()) {
  const payload = { d: deviceId, exp: Math.floor(now / 1000) + ttlSeconds };
  const body = b64(JSON.stringify(payload));
  const sig = b64(createHmac("sha256", secret).update(body).digest());
  return `${body}.${sig}`;
}

export function verifyToken(secret, token, now = Date.now()) {
  if (typeof token !== "string") return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expected = createHmac("sha256", secret).update(body).digest();
  let given;
  try {
    given = Buffer.from(sig, "base64url");
  } catch {
    return null;
  }
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  let payload;
  try {
    payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  } catch {
    return null;
  }
  if (typeof payload.d !== "string" || typeof payload.exp !== "number") return null;
  if (payload.exp * 1000 < now) return null;
  return { deviceId: payload.d, exp: payload.exp };
}

export function bearerFrom(req) {
  const h = req.headers["authorization"];
  if (!h || !h.startsWith("Bearer ")) return null;
  return h.slice(7).trim();
}
