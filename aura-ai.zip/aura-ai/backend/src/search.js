import { HttpError } from "./claude.js";

// Web search via Brave Search API. Returns only what the provider returned.
export async function webSearch(cfg, query, fetchImpl = fetch) {
  if (!cfg.braveApiKey) throw new HttpError(503, "search_not_configured");
  const url = new URL("https://api.search.brave.com/res/v1/web/search");
  url.searchParams.set("q", query);
  url.searchParams.set("count", "8");
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), cfg.requestTimeoutMs);
  let res;
  try {
    res = await fetchImpl(url, {
      signal: ctrl.signal,
      headers: { accept: "application/json", "x-subscription-token": cfg.braveApiKey },
    });
  } catch (e) {
    if (e.name === "AbortError") throw new HttpError(504, "search_timeout");
    throw new HttpError(502, "search_unreachable");
  } finally {
    clearTimeout(timer);
  }
  if (!res.ok) throw new HttpError(502, "search_upstream_error");
  const data = await res.json();
  const results = (data.web?.results || [])
    .filter((r) => typeof r.url === "string" && /^https?:\/\//.test(r.url))
    .map((r) => ({ title: String(r.title || ""), url: r.url, snippet: String(r.description || "") }));
  return { query, results };
}
