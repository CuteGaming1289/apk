// Central configuration. Secrets come only from environment variables.
export function loadConfig(env = process.env) {
  const cfg = {
    port: Number(env.PORT || 8787),
    anthropicApiKey: env.ANTHROPIC_API_KEY || "",
    anthropicModel: env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
    anthropicVersion: "2023-06-01",
    anthropicUrl: env.ANTHROPIC_URL || "https://api.anthropic.com/v1/messages",
    serverSecret: env.AURA_SERVER_SECRET || "",
    tokenTtlSeconds: Number(env.AURA_TOKEN_TTL || 60 * 60 * 24),
    rateLimitPerMinute: Number(env.AURA_RATE_LIMIT || 30),
    requestTimeoutMs: Number(env.AURA_REQUEST_TIMEOUT_MS || 20000),
    maxBodyBytes: 64 * 1024,
    maxMessages: 30,
    braveApiKey: env.BRAVE_SEARCH_API_KEY || "",
  };
  return cfg;
}

export function assertProductionConfig(cfg) {
  const missing = [];
  if (!cfg.serverSecret || cfg.serverSecret.length < 32) missing.push("AURA_SERVER_SECRET (>= 32 chars)");
  if (!cfg.anthropicApiKey) missing.push("ANTHROPIC_API_KEY");
  if (missing.length) {
    throw new Error("Missing required configuration: " + missing.join(", "));
  }
}
