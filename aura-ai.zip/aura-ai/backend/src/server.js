import http from "node:http";
import { pathToFileURL } from "node:url";
import { loadConfig, assertProductionConfig } from "./config.js";
import { issueToken, verifyToken, bearerFrom } from "./auth.js";
import { RateLimiter } from "./ratelimit.js";
import { plan, HttpError } from "./claude.js";
import { webSearch } from "./search.js";

const DEVICE_ID_RE = /^[A-Za-z0-9_-]{16,64}$/;

function send(res, status, obj, extra = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "content-type": "application/json",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    ...extra,
  });
  res.end(body);
}

async function readJson(req, maxBytes) {
  const chunks = [];
  let size = 0;
  for await (const c of req) {
    size += c.length;
    if (size > maxBytes) throw new HttpError(413, "body_too_large");
    chunks.push(c);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    throw new HttpError(400, "invalid_json");
  }
}

function sanitizeMessages(msgs, max) {
  if (!Array.isArray(msgs) || msgs.length === 0 || msgs.length > max) throw new HttpError(400, "invalid_messages");
  return msgs.map((m) => {
    if (!m || (m.role !== "user" && m.role !== "assistant")) throw new HttpError(400, "invalid_messages");
    // Only plain text or structured blocks the client got from us are accepted.
    if (typeof m.content !== "string" && !Array.isArray(m.content)) throw new HttpError(400, "invalid_messages");
    if (typeof m.content === "string" && m.content.length > 4000) throw new HttpError(400, "message_too_long");
    return { role: m.role, content: m.content };
  });
}

export function createServer(cfg, deps = {}) {
  const fetchImpl = deps.fetchImpl || fetch;
  const deviceLimiter = new RateLimiter(cfg.rateLimitPerMinute, 60_000, deps.clock);
  const registerLimiter = new RateLimiter(10, 60_000, deps.clock); // per IP

  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, "http://localhost");
      if (req.method === "GET" && url.pathname === "/health") return send(res, 200, { ok: true });

      if (req.method === "POST" && url.pathname === "/v1/auth/device") {
        const ip = req.socket.remoteAddress || "unknown";
        const rl = registerLimiter.allow(ip);
        if (!rl.ok) return send(res, 429, { error: "rate_limited" }, { "retry-after": String(rl.retryAfter) });
        const body = await readJson(req, cfg.maxBodyBytes);
        if (typeof body.deviceId !== "string" || !DEVICE_ID_RE.test(body.deviceId)) {
          throw new HttpError(400, "invalid_device_id");
        }
        const token = issueToken(cfg.serverSecret, body.deviceId, cfg.tokenTtlSeconds, deps.now?.());
        return send(res, 200, { token, expiresInSeconds: cfg.tokenTtlSeconds });
      }

      if (req.method === "POST" && (url.pathname === "/v1/agent/plan" || url.pathname === "/v1/search")) {
        const claims = verifyToken(cfg.serverSecret, bearerFrom(req), deps.now?.());
        if (!claims) throw new HttpError(401, "unauthorized");
        const rl = deviceLimiter.allow(claims.deviceId);
        if (!rl.ok) return send(res, 429, { error: "rate_limited" }, { "retry-after": String(rl.retryAfter) });
        const body = await readJson(req, cfg.maxBodyBytes);

        if (url.pathname === "/v1/agent/plan") {
          const messages = sanitizeMessages(body.messages, cfg.maxMessages);
          const context = {
            preferredLanguage: typeof body.preferredLanguage === "string" ? body.preferredLanguage.slice(0, 40) : undefined,
            timezone: typeof body.timezone === "string" ? body.timezone.slice(0, 60) : undefined,
            nowIso: typeof body.nowIso === "string" ? body.nowIso.slice(0, 40) : undefined,
          };
          const out = await plan(cfg, messages, context, fetchImpl);
          return send(res, 200, out);
        }

        if (typeof body.query !== "string" || !body.query.trim() || body.query.length > 200) {
          throw new HttpError(400, "invalid_query");
        }
        return send(res, 200, await webSearch(cfg, body.query.trim(), fetchImpl));
      }

      send(res, 404, { error: "not_found" });
    } catch (e) {
      if (e instanceof HttpError) return send(res, e.status, { error: e.code });
      console.error("internal error:", e?.message);
      send(res, 500, { error: "internal_error" });
    }
  });
}

if (import.meta.url === pathToFileURL(process.argv[1] || "").href) {
  const cfg = loadConfig();
  assertProductionConfig(cfg);
  createServer(cfg).listen(cfg.port, () => console.log(`AURA backend listening on :${cfg.port}`));
}
