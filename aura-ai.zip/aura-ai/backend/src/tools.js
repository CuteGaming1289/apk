// Tool allowlist. Claude can only request these tools; the Android app executes
// them natively. Nothing here runs code or shell commands, and every tool that
// changes state carries requiresConfirmation so the app must ask the user.

export const TOOLS = {
  call_contact: {
    description: "Find a contact by name and open the dialer for the user to review. Never places the call itself.",
    requiresConfirmation: true,
    input_schema: {
      type: "object",
      properties: { name: { type: "string", maxLength: 120 } },
      required: ["name"],
      additionalProperties: false,
    },
  },
  draft_message: {
    description: "Prepare an SMS to a contact and open the composer. The user must press send.",
    requiresConfirmation: true,
    input_schema: {
      type: "object",
      properties: {
        recipient: { type: "string", maxLength: 120 },
        body: { type: "string", maxLength: 1000 },
      },
      required: ["recipient", "body"],
      additionalProperties: false,
    },
  },
  open_app: {
    description: "Open an installed app by its display name.",
    requiresConfirmation: false,
    input_schema: {
      type: "object",
      properties: { app_name: { type: "string", maxLength: 80 } },
      required: ["app_name"],
      additionalProperties: false,
    },
  },
  search_media: {
    description: "Search the device's photos or videos via MediaStore.",
    requiresConfirmation: false,
    input_schema: {
      type: "object",
      properties: {
        kind: { type: "string", enum: ["video", "image"] },
        name_contains: { type: "string", maxLength: 120 },
        date_from: { type: "string", maxLength: 10, description: "YYYY-MM-DD" },
        date_to: { type: "string", maxLength: 10, description: "YYYY-MM-DD" },
      },
      required: ["kind"],
      additionalProperties: false,
    },
  },
  delete_media: {
    description: "Request deletion of one specific media item the user already selected. System consent dialog is always shown.",
    requiresConfirmation: true,
    input_schema: {
      type: "object",
      properties: { media_id: { type: "integer" } },
      required: ["media_id"],
      additionalProperties: false,
    },
  },
  web_search: {
    description: "Search the web and return real results. Never fabricate results.",
    requiresConfirmation: false,
    input_schema: {
      type: "object",
      properties: { query: { type: "string", maxLength: 200 } },
      required: ["query"],
      additionalProperties: false,
    },
  },
  create_reminder: {
    description: "Create a reminder. 'when' must be an ISO-8601 local date-time with offset.",
    requiresConfirmation: false,
    input_schema: {
      type: "object",
      properties: {
        title: { type: "string", maxLength: 200 },
        when: { type: "string", maxLength: 40 },
        as_alarm: { type: "boolean" },
      },
      required: ["title", "when"],
      additionalProperties: false,
    },
  },
  cancel_reminder: {
    description: "Cancel a reminder by its id.",
    requiresConfirmation: false,
    input_schema: {
      type: "object",
      properties: { reminder_id: { type: "integer" } },
      required: ["reminder_id"],
      additionalProperties: false,
    },
  },
  ask_clarification: {
    description: "Ask the user a question when a required detail is ambiguous or missing.",
    requiresConfirmation: false,
    input_schema: {
      type: "object",
      properties: { question: { type: "string", maxLength: 300 } },
      required: ["question"],
      additionalProperties: false,
    },
  },
};

export function toAnthropicTools() {
  return Object.entries(TOOLS).map(([name, t]) => ({
    name,
    description: t.description,
    input_schema: t.input_schema,
  }));
}

// Minimal strict validator for the schema subset used above.
export function validateArgs(schema, value) {
  const errors = [];
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return ["arguments must be an object"];
  }
  const props = schema.properties || {};
  for (const req of schema.required || []) {
    if (!(req in value)) errors.push(`missing required field: ${req}`);
  }
  for (const [k, v] of Object.entries(value)) {
    const p = props[k];
    if (!p) {
      if (schema.additionalProperties === false) errors.push(`unexpected field: ${k}`);
      continue;
    }
    if (p.type === "string") {
      if (typeof v !== "string") errors.push(`${k} must be a string`);
      else {
        if (p.maxLength && v.length > p.maxLength) errors.push(`${k} exceeds ${p.maxLength} chars`);
        if (p.enum && !p.enum.includes(v)) errors.push(`${k} must be one of ${p.enum.join(", ")}`);
        if (v.includes("\u0000")) errors.push(`${k} contains a null byte`);
      }
    } else if (p.type === "integer") {
      if (!Number.isInteger(v)) errors.push(`${k} must be an integer`);
    } else if (p.type === "boolean") {
      if (typeof v !== "boolean") errors.push(`${k} must be a boolean`);
    }
  }
  return errors;
}

// Returns {ok, call} or {ok:false, error}. Unknown tools are rejected.
export function validateToolCall(name, args) {
  const tool = TOOLS[name];
  if (!tool) return { ok: false, error: `tool not allowed: ${name}` };
  const errors = validateArgs(tool.input_schema, args);
  if (errors.length) return { ok: false, error: errors.join("; ") };
  return { ok: true, call: { name, args, requiresConfirmation: tool.requiresConfirmation } };
}
