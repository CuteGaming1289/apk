// Fixed-window in-memory rate limiter. For multi-instance deployments swap the
// Map for Redis; the interface (allow(key) -> {ok, retryAfter}) stays the same.
export class RateLimiter {
  constructor(limit, windowMs = 60_000, clock = () => Date.now()) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.clock = clock;
    this.buckets = new Map();
  }

  allow(key) {
    const now = this.clock();
    let b = this.buckets.get(key);
    if (!b || now - b.start >= this.windowMs) {
      b = { start: now, count: 0 };
      this.buckets.set(key, b);
    }
    if (b.count >= this.limit) {
      return { ok: false, retryAfter: Math.ceil((b.start + this.windowMs - now) / 1000) };
    }
    b.count += 1;
    return { ok: true, retryAfter: 0 };
  }

  sweep() {
    const now = this.clock();
    for (const [k, b] of this.buckets) if (now - b.start >= this.windowMs) this.buckets.delete(k);
  }
}
