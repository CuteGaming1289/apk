import test from "node:test";
import assert from "node:assert/strict";
import { issueToken, verifyToken } from "../src/auth.js";
import { RateLimiter } from "../src/ratelimit.js";
import { validateToolCall, TOOLS } from "../src/tools.js";
import { createServer } from "../src/server.js";
import { loadConfig } from "../src/config.js";

const SECRET = "x".repeat(40);
const DEVICE = "device-1234567890abcdef";

test("token round trip, tamper and expiry", () => {
  const t = issueToken(SECRET, DEVICE, 60, 1_000_000);
  assert.equal(verifyToken(SECRET, t, 1_000_000)?.deviceId, DEVICE);
  assert.equal(verifyToken(SECRET, t, 1_000_000 + 61_000), null);
  assert.equal(verifyToken("y".repeat(40), t, 1_000_000), null);
  const [b, s] = t.split(".");
  assert.equal(verifyToken(SECRET, b + "." + s.slice(0, -2) + "AA", 1_000_000), null);
  assert.equal(verifyToken(SECRET, "garbage", 1_000_000), null);
});

test("rate limiter blocks then resets", () => {
  let now = 0;
  const rl = new RateLimiter(2, 1000, () => now);
  assert.ok(rl.allow("a").ok);
  assert.ok(rl.allow("a").ok);
  assert.equal(rl.allow("a").ok, false);
  assert.ok(rl.allow("b").ok);
  now = 1001;
  assert.ok(rl.allow("a").ok);
});

test("tool validation: allowlist, required, extras, types, enums", () => {
  assert.ok(validateToolCall("call_contact", { name: "Rahul" }).ok);
  assert.equal(validateToolCall("run_shell", { cmd: "ls" }).ok, false);
  assert.equal(validateToolCall("call_contact", {}).ok, false);
  assert.equal(validateToolCall("call_contact", { name: "A", extra: 1 }).ok, false);
  assert.equal(validateToolCall("delete_media", { media_id: "5" }).ok, false);
  assert.equal(validateToolCall("search_media", { kind: "audio" }).ok, false);
  assert.equal(validateToolCall("draft_message", { recipient: "R", body: "x".repeat(1001) }).ok, false);
});

test("state-changing tools require confirmation", () => {
  for (const n of ["call_contact", "draft_message", "delete_media"]) {
    assert.equal(TOOLS[n].requiresConfirmation, true, n);
  }
});

async function withServer(cfgOverrides, fetchImpl, fn) {
  const cfg = { ...loadConfig({}), serverSecret: SECRET, anthropicApiKey: "sk-test", braveApiKey: "b-test", ...cfgOverrides };
  const server = createServer(cfg, { fetchImpl });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    await fn(base);
  } finally {
    await new Promise((r) => server.close(r));
  }
}

async function getToken(base) {
  const r = await fetch(base + "/v1/auth/device", {
    method: "POST",
    body: JSON.stringify({ deviceId: DEVICE }),
  });
  return (await r.json()).token;
}

const post = (base, path, token, body) =>
  fetch(base + path, {
    method: "POST",
    headers: { authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
  });

test("plan requires auth", async () => {
  await withServer({}, async () => assert.fail("no upstream"), async (base) => {
    const r = await post(base, "/v1/agent/plan", "bad", { messages: [{ role: "user", content: "hi" }] });
    assert.equal(r.status, 401);
  });
});

test("plan returns validated tool calls, drops disallowed ones, hides API key", async () => {
  let seen;
  const fake = async (url, init) => {
    seen = { url, headers: init.headers, body: JSON.parse(init.body) };
    return new Response(
      JSON.stringify({
        stop_reason: "tool_use",
        content: [
          { type: "text", text: "Opening the dialer for Rahul." },
          { type: "tool_use", id: "t1", name: "call_contact", input: { name: "Rahul" } },
          { type: "tool_use", id: "t2", name: "run_shell", input: { cmd: "rm -rf /" } },
          { type: "tool_use", id: "t3", name: "delete_media", input: { media_id: "bad" } },
        ],
      }),
      { status: 200 },
    );
  };
  await withServer({}, fake, async (base) => {
    const token = await getToken(base);
    const r = await post(base, "/v1/agent/plan", token, {
      messages: [{ role: "user", content: "Rahul ko call karo" }],
      preferredLanguage: "hi",
    });
    assert.equal(r.status, 200);
    const j = await r.json();
    assert.deepEqual(j.toolCalls.map((c) => c.name), ["call_contact"]);
    assert.equal(j.toolCalls[0].requiresConfirmation, true);
    assert.equal(j.rejected.length, 2);
    assert.ok(!JSON.stringify(j).includes("sk-test"));
    assert.equal(seen.headers["x-api-key"], "sk-test");
    assert.match(seen.body.system, /Preferred language: hi/);
  });
});

test("upstream failure maps to 502, not a leak", async () => {
  const fake = async () => new Response("secret upstream detail", { status: 500 });
  await withServer({}, fake, async (base) => {
    const token = await getToken(base);
    const r = await post(base, "/v1/agent/plan", token, { messages: [{ role: "user", content: "hi" }] });
    assert.equal(r.status, 502);
    assert.deepEqual(await r.json(), { error: "ai_upstream_error" });
  });
});

test("per-device rate limit returns 429", async () => {
  const fake = async () => new Response(JSON.stringify({ content: [] }), { status: 200 });
  await withServer({ rateLimitPerMinute: 2 }, fake, async (base) => {
    const token = await getToken(base);
    const body = { messages: [{ role: "user", content: "hi" }] };
    assert.equal((await post(base, "/v1/agent/plan", token, body)).status, 200);
    assert.equal((await post(base, "/v1/agent/plan", token, body)).status, 200);
    assert.equal((await post(base, "/v1/agent/plan", token, body)).status, 429);
  });
});

test("invalid input is rejected", async () => {
  await withServer({}, async () => assert.fail("no upstream"), async (base) => {
    const token = await getToken(base);
    assert.equal((await post(base, "/v1/agent/plan", token, { messages: [] })).status, 400);
    assert.equal((await post(base, "/v1/agent/plan", token, { messages: [{ role: "system", content: "x" }] })).status, 400);
    assert.equal((await post(base, "/v1/search", token, { query: "" })).status, 400);
    const bad = await fetch(base + "/v1/auth/device", { method: "POST", body: JSON.stringify({ deviceId: "short" }) });
    assert.equal(bad.status, 400);
  });
});

test("search returns only real provider results with http(s) urls", async () => {
  const fake = async () =>
    new Response(
      JSON.stringify({
        web: {
          results: [
            { title: "A", url: "https://example.com/a", description: "d" },
            { title: "Bad", url: "javascript:alert(1)", description: "x" },
          ],
        },
      }),
      { status: 200 },
    );
  await withServer({}, fake, async (base) => {
    const token = await getToken(base);
    const r = await post(base, "/v1/search", token, { query: "android tutorials" });
    const j = await r.json();
    assert.equal(j.results.length, 1);
    assert.equal(j.results[0].url, "https://example.com/a");
  });
});

test("search without provider key reports not configured", async () => {
  await withServer({ braveApiKey: "" }, async () => assert.fail("no upstream"), async (base) => {
    const token = await getToken(base);
    const r = await post(base, "/v1/search", token, { query: "x" });
    assert.equal(r.status, 503);
  });
});
